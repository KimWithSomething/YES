


from pathlib import Path
import os
from tkinter import *

from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage


OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path("./gui/Main_Screen_GUI")


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)





def LaunchCountryCreation():
    os.system('dir')

def LaunchCountryEditor():
    os.system('dir')


window = Tk()
window.title('Country')
window.geometry("1152x653")
window.configure(bg = "#7B7B7B")


canvas = Canvas(
    window,
    bg = "#7B7B7B",
    height = 653,
    width = 1152,
    bd = 0,
    highlightthickness = 0,
    relief = "ridge"
)

canvas.place(x = 0, y = 0)
canvas.create_rectangle(
    329.0,
    20.0,
    774.0,
    121.0,
    fill="#C4C4C4",
    outline="")

canvas.create_text(
    382.0,
    35.0,
    anchor="nw",
    text="Country Tool",
    fill="#000000",
    font=("Roboto", 60 * -1)
)

button_image_1 = PhotoImage(
    file=relative_to_assets("Country_Creation.png"))
Country_Creation = Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=LaunchCountryCreation,
    relief="flat"
)
Country_Creation.place(
    x=78.0,
    y=285.0,
    width=293.0,
    height=177.0
)

button_image_2 = PhotoImage(
    file=relative_to_assets("Country_Editor.png"))
Country_Editor = Button(
    image=button_image_2,
    borderwidth=0,
    highlightthickness=0,
    command=LaunchCountryEditor,
    relief="flat"
)
Country_Editor.place(
    x=789.0,
    y=285.0,
    width=293.0,
    height=177.0
)
window.resizable(False, False)
window.mainloop()
