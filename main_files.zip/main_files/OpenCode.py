import os


os.system('code .')