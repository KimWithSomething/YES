import easygui
import math

file = easygui.fileopenbox()


print(file)



ModPath= file[0:-14]



def Update_Mod_Path_Info(path,Path_Info):
    f = open(f"{path}Mod_Path.kad", "w")
    f.write(Path_Info)
    
def Update_Mod_Info(path,Mod_Info):
    f = open(f"{path}Mod_Info.kad", "w")
    f.write(Mod_Info)
print(ModPath)

Update_Mod_Path_Info('',ModPath)
Update_Mod_Path_Info('./Country_Tool/',ModPath)
Update_Mod_Path_Info('./Country_Tool/Country_Editor/',ModPath)
Update_Mod_Path_Info('./Country_Tool/Country_Creation/',ModPath)
a = input()