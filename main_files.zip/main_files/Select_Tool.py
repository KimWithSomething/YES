


from pathlib import Path
import os
from tkinter import *

from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage
os.system('start cmd')

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path("./gui/Select_GUI")


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

Mod_tools=['Country Tool','Flag Tool']
window = Tk()

window.geometry("344x196")
window.configure(bg = "#7B7B7B")

window.title('slecet tool')
canvas = Canvas(
    window,
    bg = "#7B7B7B",
    height = 196,
    width = 344,
    bd = 0,
    highlightthickness = 0,
    relief = "ridge"
)

canvas.place(x = 0, y = 0)
canvas.create_rectangle(
    26.0,
    9.0,
    319.0,
    50.0,
    fill="#C4C4C4",
    outline="")

canvas.create_text(
    33.0,
    12.0,
    anchor="nw",
    text="Kims HOI4 Mod Tool",
    fill="#000000",
    font=("Roboto", 30 * -1)
)
def Open_Tool():
    P = str(verison2.get())
    
    if P == 'Country Tool':
        os.system('python ./main_files/Country_Tool/Main_Screen_GUI.py')
    


button_image_1 = PhotoImage(
    file=relative_to_assets("button_1.png"))
button_1 = Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=Open_Tool,
    relief="flat",
    bg='#7B7B7B'
)
button_1.place(
    x=146.0,
    y=144.0,
    width=53.0,
    height=26.0
)
verison2= StringVar(window)
verison2.set('Select a tool')
w = OptionMenu(window,verison2,*Mod_tools)
  
w.place(
    
    x=146.0,
    y=100.0, 
    
    
)


window.resizable(False, False)
window.mainloop()
